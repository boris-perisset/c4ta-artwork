# FXHash_p5 

p5js template for https://www.fxhash.xyz/. Uses fxrand() seed for deterministic random sequences.

Susuwatari

The Soot Sprites (すすワタリ, Susuwatari, lit. "Travelling Soot" a.k.a. "Mak-kuro Kurosuke") are spirits that appear in the films My Neighbor Totoro and Spirited Away. They are small, round balls made from the soot that dwells in old and abandoned houses and leave black dirt in their wake. If the house becomes inhabited, they decide if the inhabitants are nice people. If they are, they will leave.


This Artwork is under the creative commons license: 
Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
https://creativecommons.org/licenses/by-sa/4.0/

 
